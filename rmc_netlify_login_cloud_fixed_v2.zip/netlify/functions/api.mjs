import { getStore as netlifyGetStore } from "@netlify/blobs";
import crypto from "node:crypto";

const STORE_NAME = "rmc-system";
const STATE_KEY = "state";
const USERS_KEY = "users";
const SESS_PREFIX = "session:";
const SESSION_MS = 24 * 60 * 60 * 1000;

const seed = {
  AT: [],
  QT: [
    {id:1,dt:"2026-08-22",cu:"RINKU AGGARWAR",cn:"9999747552",co:"PARDEEP",si:"MALHA MAJRA",gr:"M25",qty:200,rate:4800,total:960000,sts:"Sent",vt:"2026-09-10",nt:"Standard RMC quote"},
    {id:2,dt:"2026-08-23",cu:"RAMBIR RATHI",cn:"9811960900",co:"YOGESH",si:"PLOT NO. 344 IMT",gr:"M10/M30",qty:500,rate:4500,total:2250000,sts:"Follow-up",vt:"2026-09-30",nt:"PCC + RCC both"},
    {id:3,dt:"2026-08-24",cu:"KEC/Maruti",cn:"7499922442",co:"Mr. Ravi",si:"IMT Kharkhoda",gr:"Multiple",qty:1000,rate:5200,total:5200000,sts:"Draft",vt:"2026-10-15",nt:"Multiple grades"}
  ],
  R: [{"id":1,"sp":"Parvinder Kumar","vd":"2026-08-22","cu":"NIKHIL & PARDEEP","cn":"NA","co":"PARDEEP","cc":"9555445836","si":"RELEMAC TECHNOLOGIES PVT LTD","sa":"MALHA MAJRA","ar":"","gr":"","rd":"","rm":"MADAN MUNSI 8938045177"},{"id":2,"sp":"Parvinder Kumar","vd":"2026-08-22","cu":"RINKU AGGARWAR","cn":"9999747552","co":"PARDEEP","cc":"9555445836","si":"MALHA MAJRA","sa":"MALHA MAJRA","ar":"1000","gr":"M25","rd":"2026-09-06","rm":"MADAN MUNSI 8938045177"},{"id":3,"sp":"Parvinder Kumar","vd":"2026-08-22","cu":"ARYAN DAHIYA","cn":"9868349897","co":"ARYAN DAHIYA","cc":"9868349897","si":"MALHA MAJRA","sa":"MALHA MAJRA","ar":"2000","gr":"M25","rd":"2026-08-29","rm":"ONLY FLOORING"},{"id":4,"sp":"Parvinder Kumar","vd":"2026-08-22","cu":"ANIL GUPTA","cn":"","co":"RAJAN","cc":"7879858395","si":"MALHA MAJRA","sa":"MALHA MAJRA","ar":"1700","gr":"M25","rd":"2026-08-29","rm":"RINKU 9992800401"},{"id":5,"sp":"Parvinder Kumar","vd":"2026-08-22","cu":"ANIL GUPTA","cn":"","co":"RAJAN","cc":"7879858395","si":"MALHA MAJRA","sa":"MALHA MAJRA","ar":"11000","gr":"M25","rd":"","rm":"FLORING & LANTER"},{"id":6,"sp":"Parvinder Kumar","vd":"2026-08-22","cu":"RAJ KUMAR","cn":"9818169834","co":"KAPIL","cc":"9973066337","si":"MALHA MAJRA","sa":"MALHA MAJRA","ar":"10000","gr":"M25","rd":"2026-09-11","rm":"NEAR RADHA SWAMI SATSANG NAHRI ROAD"},{"id":7,"sp":"Pawan Kumar","vd":"2026-08-21","cu":"NA","cn":"NA","co":"Chandan","cc":"7979802368","si":"Plot no. 27-28","sa":"Sec-7 Rajdhani","ar":"","gr":"","rd":"","rm":""},{"id":8,"sp":"Pawan Kumar","vd":"2026-08-21","cu":"NA","cn":"NA","co":"SONU","cc":"9991417151","si":"SHOWROOM","sa":"LABOU CHOWK KHARKHODA","ar":"1000","gr":"","rd":"","rm":""},{"id":9,"sp":"Pawan Kumar","vd":"2026-08-21","cu":"NA","cn":"NA","co":"ANKUR","cc":"8640000709","si":"SANT KABIR FARM HOUSE","sa":"DELHI ROAD KHARKHODA","ar":"","gr":"","rd":"","rm":"OLD RMC DEALER DHOLPUR RMC PLANT"},{"id":10,"sp":"Pawan Kumar","vd":"2026-08-22","cu":"NA","cn":"NA","co":"NITIN GUPTA","cc":"9871066092","si":"PLOT NO. 2500","sa":"IMT KHARKHODA","ar":"800","gr":"","rd":"","rm":"WHEN REQURED CALL"},{"id":11,"sp":"Pawan Kumar","vd":"2026-08-22","cu":"NA","cn":"NA","co":"J K DUBEY","cc":"9971769836","si":"PLOT NO. 2503","sa":"IMT KHARKHODA","ar":"800","gr":"M25","rd":"2026-08-28","rm":"LABOUR THEKEDAR TILAK RAJ 7289940157"},{"id":12,"sp":"Pawan Kumar","vd":"2026-08-22","cu":"NA","cn":"NA","co":"BIMAL PARSHAD","cc":"7633894798","si":"POWAR HOUSE","sa":"IMT KHARKHODA","ar":"","gr":"M40","rd":"2026-09-02","rm":"SUPERVISOR DHANJAY 9570255627 (QUOTATION GIVEN WITH GST 6077/-)"},{"id":13,"sp":"Pawan Kumar","vd":"2026-08-23","cu":"RAMBIR RATHI","cn":"9811960900","co":"YOGESH","cc":"8930348669","si":"PLOT NO. 344","sa":"IMT KHARKHODA","ar":"25000","gr":"M10/M30","rd":"2026-09-23","rm":"PCC AND RCC BOTH REQUIRED LAST RCC SUPPLIER LADRAWAN PLANT"},{"id":14,"sp":"Pawan Kumar","vd":"2026-08-23","cu":"NA","cn":"NA","co":"RAHISH ALI","cc":"9990373858","si":"PLOT NO. 761","sa":"IMT KHARKHODA","ar":"25000","gr":"M30","rd":"","rm":"2 FLOOR COMPLETED LABOUR CONT SHEKHAR 8739937374"},{"id":15,"sp":"Pawan Kumar","vd":"2026-08-23","cu":"SHAILASH","cn":"","co":"PREM PANDAY","cc":"9210137131","si":"PLOT NO. 320","sa":"IMT KHARKHODA","ar":"2000","gr":"","rd":"","rm":"2 FLOOR COMPLETED LABOUR CONT VAIDNATH 9910764412"},{"id":16,"sp":"Pawan Kumar","vd":"2026-08-21","cu":"NA","cn":"NA","co":"ANKUR","cc":"8640000709","si":"SANT KABIR FARM HOUSE","sa":"DELHI ROAD KHARKHODA","ar":"","gr":"M25","rd":"2026-09-03","rm":"REQUIRED RMC 03 SEP 26"},{"id":17,"sp":"Pawan Kumar","vd":"2026-08-22","cu":"NA","cn":"NA","co":"NITIN GUPTA","cc":"9871066092","si":"PLOT NO. 2500","sa":"IMT KHARKHODA","ar":"800","gr":"M50","rd":"2026-09-23","rm":"RMC REQUIRED 23-SEP-26"},{"id":18,"sp":"Pawan Kumar","vd":"2026-08-22","cu":"NA","cn":"NA","co":"J K DUBEY","cc":"9971769836","si":"PLOT NO. 2503","sa":"IMT KHARKHODA","ar":"800","gr":"M25","rd":"2026-08-28","rm":"LABOUR THEKEDAR TILAK RAJ 7289940157"},{"id":19,"sp":"Pawan Kumar","vd":"2026-08-22","cu":"NA","cn":"NA","co":"BIMAL PARSHAD","cc":"7633894798","si":"POWAR HOUSE","sa":"IMT KHARKHODA","ar":"","gr":"M40","rd":"2026-09-02","rm":"SUPERVISOR DHANJAY 9570255627 RMC REQUIRED 08-SEP-26"},{"id":20,"sp":"Parvinder Kumar","vd":"2026-08-24","cu":"KEC/Maruti","cn":"7499922442","co":"Mr. Ravi","cc":"7499922442","si":"IMT Kharkhoda","sa":"IMT Kharkhoda","ar":"","gr":"Multiple","rd":"2026-10-01","rm":""}],
  SL: [{"id":1,"nm":"Parvinder Kumar","rl":"Sales Executive","dp":"Sales","ph":"9876543210","em":"parvinder@rmc.com","jd":"2024-01-01","st":"Active","cl":"#1a56db"},{"id":2,"nm":"Pawan Kumar","rl":"Sales Executive","dp":"Sales","ph":"9876543211","em":"pawan@rmc.com","jd":"2024-01-01","st":"Active","cl":"#057a55"}],
  OS: [{"id":1,"nm":"Rajesh Sharma","rl":"Office Manager","dp":"Admin","ph":"9812300001","st":"Active","cl":"#7c3aed"},{"id":2,"nm":"Sunita Devi","rl":"Accounts Executive","dp":"Accounts","ph":"9812300002","st":"Active","cl":"#e02424"},{"id":3,"nm":"Amit Verma","rl":"Data Entry","dp":"Operations","ph":"9812300003","st":"Active","cl":"#f59e0b"}],
  WL: [{"id":1,"sn":"Rajesh Sharma","dt":"2026-08-24","tk":"Prepare monthly billing report","sts":"Done","pr":"High","nt":"Sent to accounts"},{"id":2,"sn":"Sunita Devi","dt":"2026-08-24","tk":"GST filing for August","sts":"In Progress","pr":"High","nt":"Due today"},{"id":3,"sn":"Amit Verma","dt":"2026-08-24","tk":"Update customer database","sts":"Pending","pr":"Medium","nt":""}]
};

const initialUsers = [
  {id:"u-owner", loginId:"owner", name:"Company Owner", role:"owner", password:"RMC@2026!"},
  {id:"u-parvinder", loginId:"parvinder", name:"Parvinder Kumar", role:"sales", staffId:1, password:"Parv@123"},
  {id:"u-pawan", loginId:"pawan", name:"Pawan Kumar", role:"sales", staffId:2, password:"Pawan@123"},
  {id:"u-rajesh", loginId:"rajesh", name:"Rajesh Sharma", role:"office", staffId:1, password:"Rajesh@123"},
  {id:"u-sunita", loginId:"sunita", name:"Sunita Devi", role:"office", staffId:2, password:"Sunita@123"},
  {id:"u-amit", loginId:"amit", name:"Amit Verma", role:"office", staffId:3, password:"Amit@123"}
];

function json(data,status=200){
  return new Response(JSON.stringify(data),{status,headers:{"content-type":"application/json; charset=utf-8","cache-control":"no-store","pragma":"no-cache"}});
}
function hashPassword(password,salt=crypto.randomBytes(16).toString("hex")){
  const hash=crypto.scryptSync(password,salt,64).toString("hex");
  return {salt,hash};
}
function verifyPassword(password,rec){
  if(!rec?.hash||!rec?.salt)return false;
  try{
    const h=crypto.scryptSync(password,rec.salt,64).toString("hex");
    return crypto.timingSafeEqual(Buffer.from(h,"hex"),Buffer.from(rec.hash,"hex"));
  }catch{return false;}
}
function clone(x){return JSON.parse(JSON.stringify(x));}
function same(a,b){return JSON.stringify(a)===JSON.stringify(b);}
function mapById(arr){const m=new Map();(arr||[]).forEach(x=>m.set(String(x.id),x));return m;}
function mergeChanges(currentArr,baseArr,incomingArr,owns){
  const base=mapById(baseArr), incoming=mapById(incomingArr), current=mapById(currentArr);
  for(const [id,n] of incoming){
    const b=base.get(id);
    if(!b){if(owns(null,n))current.set(id,clone(n));continue;}
    if(!same(b,n)&&owns(current.get(id)||b,n))current.set(id,clone(n));
  }
  for(const [id,b] of base){
    if(!incoming.has(id)&&owns(current.get(id)||b,null))current.delete(id);
  }
  return Array.from(current.values());
}
function normalizeState(s){
  const x=s||{};
  return {AT:Array.isArray(x.AT)?x.AT:[],QT:Array.isArray(x.QT)?x.QT:[],R:Array.isArray(x.R)?x.R:[],SL:Array.isArray(x.SL)?x.SL:[],OS:Array.isArray(x.OS)?x.OS:[],WL:Array.isArray(x.WL)?x.WL:[]};
}
function maxId(arr){return (arr||[]).reduce((m,x)=>Math.max(m,Number(x.id)||0),0)+1;}

function getStore(){
  // Netlify supplies the Blobs connection automatically to deployed Functions.
  return getStoreCached();
}
let storeCached;
function getStoreCached(){
  if(!storeCached)storeCached = netlifyGetStore("rmc-system",{consistency:"strong"});
  return storeCached;
}

async function loadState(store){
  let data=await store.get(STATE_KEY,{type:"json",consistency:"strong"});
  if(!data){data=clone(seed);await store.setJSON(STATE_KEY,data);}
  return normalizeState(data);
}
async function loadUsers(store){
  let users=await store.get(USERS_KEY,{type:"json",consistency:"strong"});
  if(!users){
    users=initialUsers.map(u=>{const p=hashPassword(u.password);const x={...u};delete x.password;return {...x,...p};});
    await store.setJSON(USERS_KEY,users);
  }
  return users;
}
async function currentUser(req,store){
  const token=req.headers.get("authorization")?.replace(/^Bearer\s+/i,"").trim();
  if(!token)return null;
  const s=await store.get(SESS_PREFIX+token,{type:"json"});
  if(!s||s.exp<Date.now())return null;
  const users=await loadUsers(store);
  return users.find(u=>u.id===s.userId)||null;
}
async function publicState(s,store){
  const out=clone(s);const users=await loadUsers(store);
  for(const u of users){
    if(u.role==="sales"&&u.staffId){const x=out.SL.find(v=>v.id===u.staffId);if(x){x.loginId=u.loginId;x.userId=u.id;}}
    if(u.role==="office"&&u.staffId){const x=out.OS.find(v=>v.id===u.staffId);if(x){x.loginId=u.loginId;x.userId=u.id;}}
  }
  return out;
}

export default async function handler(req){
  const url=new URL(req.url);
  const path=url.pathname.replace(/\/+$/g,"")||"/";
  const store=getStore();

  try{
    // Simple public health endpoint. This is useful for confirming that the
    // Netlify Function is actually deployed before attempting a login.
    if(req.method==="GET"&&path.endsWith("/health")){
      return json({ok:true,service:"rmc-api",storage:"netlify-blobs"});
    }

    let body={};
    if(req.method!=="GET"&&req.method!=="HEAD"){
      const text=await req.text();
      if(text){try{body=JSON.parse(text);}catch{return json({ok:false,error:"Invalid JSON request."},400);}}
    }

    if(req.method==="POST"&&(path.endsWith("/login")||body.action==="login")){
      const users=await loadUsers(store);
      const loginId=String(body.loginId||"").trim().toLowerCase();
      const user=users.find(u=>String(u.loginId||"").toLowerCase()===loginId);
      if(!user||!verifyPassword(String(body.password||""),user))return json({ok:false,error:"Invalid login ID or password."},401);
      const st=await loadState(store);
      if(user.role==="sales"&&!st.SL.some(x=>x.id===user.staffId&&x.st==="Active"))return json({ok:false,error:"This staff account is inactive."},403);
      if(user.role==="office"&&!st.OS.some(x=>x.id===user.staffId&&x.st==="Active"))return json({ok:false,error:"This staff account is inactive."},403);
      const token=crypto.randomBytes(32).toString("hex");
      await store.setJSON(SESS_PREFIX+token,{userId:user.id,exp:Date.now()+SESSION_MS});
      return json({ok:true,token,user:{id:user.id,name:user.name,role:user.role,staffId:user.staffId||null}});
    }

    if(req.method==="POST"&&body.action==="logout"){
      const token=req.headers.get("authorization")?.replace(/^Bearer\s+/i,"").trim();
      if(token)await store.delete(SESS_PREFIX+token);
      return json({ok:true});
    }

    const user=await currentUser(req,store);
    if(!user)return json({ok:false,error:"Please log in again."},401);

    if(req.method==="GET"){
      return json({ok:true,state:await publicState(await loadState(store),store),user:{name:user.name,role:user.role,staffId:user.staffId||null}});
    }
    if(req.method!=="POST")return json({ok:false,error:"Method not allowed"},405);

    if(body.action==="saveState"){
      const old=await loadState(store);const incoming=normalizeState(body.state);const base=normalizeState(body.baseState||body.state);let next=clone(old);
      if(user.role==="owner"){
        for(const k of Object.keys(next))next[k]=mergeChanges(old[k],base[k],incoming[k],()=>true);
      }else if(user.role==="sales"){
        const me=user.name;
        next.R=mergeChanges(old.R,base.R,incoming.R,(o,n)=>(o?.sp||n?.sp)===me);
        next.AT=mergeChanges(old.AT,base.AT,incoming.AT,(o,n)=>(o?.nm||n?.nm)===me);
      }else{
        const me=user.name;
        next.WL=mergeChanges(old.WL,base.WL,incoming.WL,(o,n)=>(o?.sn||n?.sn)===me);
        next.AT=mergeChanges(old.AT,base.AT,incoming.AT,(o,n)=>(o?.nm||n?.nm)===me);
      }
      await store.setJSON(STATE_KEY,next);
      return json({ok:true,state:await publicState(next,store)});
    }

    if(body.action==="saveEmployee"){
      if(user.role!=="owner")return json({ok:false,error:"Owner access required."},403);
      const users=await loadUsers(store);const d=body.employee||{};const loginId=String(d.loginId||"").trim().toLowerCase();
      if(!loginId||!d.name)return json({ok:false,error:"Name and login ID are required."},400);
      const exists=users.find(u=>u.loginId.toLowerCase()===loginId&&u.id!==d.userId);
      if(exists)return json({ok:false,error:"Login ID already exists."},409);
      let u=users.find(x=>x.id===d.userId)||users.find(x=>x.staffId===d.staffId&&x.role===d.role);
      if(!u){u={id:"u-"+crypto.randomBytes(8).toString("hex")};users.push(u);}
      u.loginId=loginId;u.name=String(d.name);u.role=d.role;u.staffId=d.staffId||null;
      if(d.password){const p=hashPassword(String(d.password));u.salt=p.salt;u.hash=p.hash;}
      if(!u.hash){const p=hashPassword(crypto.randomBytes(12).toString("base64url"));u.salt=p.salt;u.hash=p.hash;}
      await store.setJSON(USERS_KEY,users);
      return json({ok:true,user:{id:u.id,loginId:u.loginId,name:u.name,role:u.role,staffId:u.staffId}});
    }

    if(body.action==="deleteEmployee"){
      if(user.role!=="owner")return json({ok:false,error:"Owner access required."},403);
      const users=await loadUsers(store);const id=body.userId;const next=users.filter(x=>x.id!==id||x.role==="owner");
      await store.setJSON(USERS_KEY,next);return json({ok:true});
    }

    if(body.action==="changeOwnerPassword"){
      if(user.role!=="owner")return json({ok:false,error:"Owner access required."},403);
      const users=await loadUsers(store);const u=users.find(x=>x.id===user.id);const p=String(body.password||"");
      if(p.length<8)return json({ok:false,error:"Password must be at least 8 characters."},400);
      const h=hashPassword(p);u.salt=h.salt;u.hash=h.hash;await store.setJSON(USERS_KEY,users);return json({ok:true});
    }

    return json({ok:false,error:"Unknown action"},400);
  }catch(e){
    console.error("RMC API error:",e);
    return json({ok:false,error:"Server error: "+(e?.message||"Unknown error")},500);
  }
}
